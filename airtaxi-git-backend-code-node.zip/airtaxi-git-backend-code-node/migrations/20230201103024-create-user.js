'use strict';

const { sequelize } = require('../models');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name:{
        type:Sequelize.STRING,
        allowNull:true,
        get(){
          return `${this.first_name} + ${this.last_name}`
        }
      },
      first_name:{
        type:Sequelize.STRING,
        allowNull:true
      },
      refersh_token:{
        type:Sequelize.TEXT
      },
      token:{
        type:Sequelize.TEXT,
        defaultValue:null
      },
     
      last_name:{
        type:Sequelize.STRING,
        allowNull:true
      },
      email: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      password: {
        type: Sequelize.STRING,
      },
      phone_number:{
        type: Sequelize.STRING,
        allowNull:true
      },
      profile_pic:{
          type:Sequelize.STRING,
          allowNull:true
      },
      country_code:{
        type:Sequelize.STRING,
      },
      device_id:{
        type: Sequelize.STRING,
        allowNull:true
      },
      otp:{
        type: Sequelize.STRING,
      },
      verified:{
        type: Sequelize.STRING,
      },
      device_type:{
        type: Sequelize.STRING,
        defaultValue:null
      },
      social_type:{
        type:Sequelize.STRING,
        defaultValue:null
      },
      social_id:{
        type:Sequelize.STRING,
        defaultValue:""
      },
     
      location:{
        type:Sequelize.STRING,
        allowNull:true
      },
      user_role:{
        type:Sequelize.ENUM('1','2','3'),
        Comment:'1 => Admin,2 => NormalUser,3 => Employee',
        defaultValue:'2'
      },
      status:{
        type:Sequelize.BOOLEAN,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('users');
  }
};