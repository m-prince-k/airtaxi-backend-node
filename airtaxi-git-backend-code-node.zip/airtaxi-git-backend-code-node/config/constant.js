const STAGING_BASE_URL="https://stgphys.appsndevs.com/airtaxi"
const LOCAL_BASE_URL="http://localhost:3001/airtaxi"
module.exports={STAGING_BASE_URL,LOCAL_BASE_URL}