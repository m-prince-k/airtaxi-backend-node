const jwt = require("jsonwebtoken");
const bcrypt = require('bcrypt');
const { STATUSCODE } = require("./messages");
require("dotenv").config()
exports.catchErrorResponse = (res, msg) => {
    var data = {
        status: 500,
        message: msg,
    };
    return res.status(500).json(data);
}

exports.successResponse = (res, msg) => {
    var data = {
        status: 200,
        message: msg
    };
    return res.status(200).json(data);
}

exports.passwordNotMatch = (res, msg) => {
    var data = {
        status: 401,
        message: msg
    };
    return res.status(400).json(data);
}

exports.customSuccessResponse = (res, msg, statuscode) => {
    var data = {
        status: statuscode,
        message: msg
    };
    return res.status(statuscode).json(data);
}

exports.successResponseWithData = (res, msg, data) => {
    var data = {
        status: 200,
        message: msg,
        data: data
    };
    return res.status(200).json(data);
}
exports.EmailsentSuccesfully=(res,msg,data)=>{
    var data = {
        status: 200,
        message: msg,
        data: data
    };
    return res.status(200).json(data);
}
exports.successResponseWithExtraData = function (res, msg, extraData, data) {
    var resData = {
        status: 200,
        message: msg,
        extraData,
        data: data
    };
    return res.status(200).json(resData);
}

exports.customSuccessResponseWithData = (res, msg, data,statuscode) => {
    var data = {
        status: statuscode,
        message: msg,
        data: data
    };
    return res.status(statuscode).json(data);
}

exports.errorRespose = (res, msg) => {
    var data = {
        status: 400,
        message: msg
    };
    return res.status(400).json(data);
}

exports.customerrorRespose = (res, msg,statuscode) => {
    var data = {
        status: statuscode,
        message: msg
    };
    return res.status(statuscode).json(data);
}

exports.errorResposeWithData = (res, msg, data) => {
    var data = {
        status: 400,
        message: msg,
        data: data
    };
    return res.status(400).json(data);
}

exports.validationError = (res, msg) => {
    var data = {
        status: 422,
        message: msg
    };
    return res.status(422).json(data);
}

exports.validationErrorWithData = (res, msg, data) => {
    var data = {
        status: 422,
        message: msg,
        data: data
    };
    return res.status(422).json(data);
}

exports.unAuthorizedResponse = (res, msg) => {
    var data = {
        status: 401,
        message: msg,
    };
    return res.status(401).json(data);
}
exports.failedResponse = (res,msg) => {
    return res.status().json({
      status:statusCode,
      message:msg
    })
  }
  exports.customFailedResponse = (res,msg,statusCode) => {
    return res.status(statusCode).json({
      status:statusCode,
      message:msg
    })
  }
exports.hashPassword= async(password,salt) => {
    return await bcrypt.hash(password,salt);
}
    exports.comparePassword=async(old_password,db_password) => {
        return await bcrypt.compare(old_password,db_password).then(res => {
            return res
        });
    }
exports.generateToken= async (data,JWTSECRETKEY,) =>{
    return await jwt.sign(data,'Wx3!UzwdsxY',{expiresIn:"365d"});
}
exports.generateRefreshToken= async (data,JWTSECRETKEY,) =>{
    return await jwt.sign(data,'Wx3!UzwdsxY',{expiresIn:"5m"});
}

exports.checkOwnerExistOrNotByEmail=async function(email) {
    let checkUserExistsOrNot=await User.findOne({where:{email:email}});
    return checkUserExistsOrNot;
}
exports.checkEntityExistsOrNot = async (model,condition) => {
    return new Promise(async (resolve,reject) => {
        const record = await model.findOne(condition);
        if(record) {
            console.log(record);
            resolve(record)
        } else {
            reject('not found')
        }
    }).catch((err) => {
        console.log(err)
    })
}
exports.checkOwnerExistOrNot=async function(owner_id) {
  //console.log(typeof _nameColumb);return
  let checkRestaurentExistOrNot=await User.findOne({where:{id:owner_id}});
  return checkRestaurentExistOrNot;
}
exports.checkItemExistsInArrayOrNot = async (array,item) => {
    return new Promise(async (resolve,reject) => {
     console.log(item)
            let resultant=false
            for(let i=0;i<=array.length;i++){

               
                if(array[i]?.dataValues?.email==item) {
                    resultant=true
                   reresolve(resultant)
                   
                } else{
                     resultant=false
                    return reject(resultant)
                    }
             
        }
    });
}
exports.makeid = async (length) =>  {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}

