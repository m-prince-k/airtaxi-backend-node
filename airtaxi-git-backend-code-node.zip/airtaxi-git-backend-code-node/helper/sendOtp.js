
const helper = {};
const Promise = require('promise');
const { resolve, reject } = require('promise');

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhoneNumber = process.env.TWILIO_NUMBER;
const client = require('twilio')(accountSid, authToken);
const sendVerificationCode = async (data) => {
    //generat auth tag for uniqueness...        
     return client.messages.create({
        body: data.message,
        from: twilioPhoneNumber,
        to: data.phoneNumber,
    })
        .then(function (message) {
            return message.sid;
        }).catch(
            (e) => {
                console.log(e.message);
                return;
            }); 
}


exports.generateOtp=async(phoneNumber,otpNumber)=>{
  try {
  
    let messageData = {
      message: 'Your verification code is :' + otpNumber, phoneNumber: phoneNumber,
    };
    let sendMessage = await sendVerificationCode(messageData);
    console.log(`Message send successfully to - ${phoneNumber} `)
  } catch (error) {
console.log(error)  }
}
// const register = await User.create(data);
// const phoneNumber=req.body.phoneNumber
// var otp=await generateOtp.generateOtp(phoneNumber)
// const sendmail = await sendMailer(email, token, );