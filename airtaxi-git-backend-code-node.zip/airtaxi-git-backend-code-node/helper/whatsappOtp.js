
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_NUMBER=process.env.TWILIO_NUMBER;
const client = require('twilio')(accountSid, authToken);

exports.sendWhatsappCode=async (phone_number,otpNumber)=>{
  console.log("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP")
    client.messages
      .create({
         from: `whatsapp:${TWILIO_NUMBER}`,
         body: otpNumber,
         to: `whatsapp:${phone_number}`
       })
      .then(message => console.log(message.sid));
    
    let sendMessage = await sendWhatsappCode("kjb v");
    console.log(sendMessage)
 
    }