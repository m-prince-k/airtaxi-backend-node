

const nodemailer = require("nodemailer");

// async..await is not allowed in global scope, must use a wrapper
let welcomeMail = async (email1,name1) => {

  let testAccount = await nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: process.env.HOST,
    port: 587,
    auth: {
      user: "seasia.developers2@gmail.com", // generated ethereal user
      pass: "efxnmoxdnxvxvjnv", // generated ethereal password
    },
  });

  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: "seasia.developers2@gmail.com", // sender address
    to: email1, // list of receivers
    subject: "Welcome to Airtaxi ", // Subject lin
    html:`<h2> ${name1}Thanks for register on our site </h2>`
        })


  transporter.sendMail(info, function(error, response){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + response.response);
    }
  });
}

module.exports = welcomeMail