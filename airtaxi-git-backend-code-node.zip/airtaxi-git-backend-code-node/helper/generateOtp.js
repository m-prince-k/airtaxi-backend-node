

// exports.generateOtp=async(phoneNumber,res)=>{
//     console.log("phoneNumber")
//     try {
//       let code = Math.floor(100000 + Math.random() * 900000)
//       let messageData = {
//         message: 'Your verification code is :' + code, phoneNumber: phoneNumber,
//       };
//       let sendMessage = await sendVerificationCode(messageData);
//       console.log(`Message send successfully to - ${phoneNumber}`)
//     } catch (error) {
//   console.log(error)  }
//   }