const nodemailer = require("nodemailer");

// async..await is not allowed in global scope, must use a wrapper
let sendMailer = async (email,otpNumber) => {
  

  let testAccount = await nodemailer.createTestAccount();
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: process.env.HOST,
    port: process.env.EMAILPORT,
    auth: {
      user: process.env.USERMAIL, // generated ethereal user
      pass: process.env.PASS, // generated ethereal password
    },
  })
  let info = await transporter.sendMail({
    from: process.env.USERMAIL, // sender address
    to: email, // list of receivers
    subject: "Verify Otp", // Subject lin
    html: `<h4>Hey ! Welcome to Airtaxi app  </h4>
    <a><h3>${otpNumber} </h3>this is your otp</a>`, // html body
  });


  transporter.sendMail(info, function(error, response){
    if (error) {
      console.log(error);
    } else {
      console.log(response)
    }
  });
}

module.exports = sendMailer

