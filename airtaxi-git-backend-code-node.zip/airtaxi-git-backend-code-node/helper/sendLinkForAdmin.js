const nodemailer = require("nodemailer");

// async..await is not allowed in global scope, must use a wrapper
let sendMailer = async (to,from,subject,html) => {


  let testAccount = await nodemailer.createTestAccount();
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    auth: {
      user: "seasia.developers2@gmail.com", // generated ethereal user
      pass: "efxnmoxdnxvxvjnv", // generated ethereal password
    },
  })
  let info = await transporter.sendMail({
    from: from, // sender address
    to: to, // list of receivers
    subject: subject, // Subject lin
    html: `Forgot Password Link is here ${html}`, // html body
  });


  transporter.sendMail(info, function(error, response){
    if (error) {
      console.log(error);
    } else {
      console.log(response)
      response.send('Email sent check : ' + response.response);
    }
  });
}

module.exports = sendMailer
