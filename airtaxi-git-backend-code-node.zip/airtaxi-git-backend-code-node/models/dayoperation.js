'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class DayOperation extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      DayOperation.belongsTo(models.Flight,{foreignKey:'id'})
      DayOperation.belongsTo(models.Day,{foreignKey:'day_id'})
    }
  }
  DayOperation.init({
    flight_id: DataTypes.INTEGER,
    day_id: DataTypes.INTEGER,
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    },
  }, {
    sequelize,
    modelName: 'DayOperation',
    tableName:'dayoperations'
  });
  return DayOperation;
};