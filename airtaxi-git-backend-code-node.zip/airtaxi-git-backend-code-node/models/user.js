"use strict";
const { Model } = require("sequelize");
const path=require("path")
module.exports = (sequelize, DataTypes) => {
  const { STRING, BOOLEAN } = DataTypes;
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  User.init(
    {
      name:{
        type:DataTypes.STRING,
        allowNull:true,
      },
      first_name:{
        type:DataTypes.STRING,
        allowNull:true
      },
      last_name:{
        type:DataTypes.STRING,
        allowNull:true
      },
      phone_number: {
        type: DataTypes.STRING,
      },
      email: {
      type: DataTypes.STRING },
      password: { 
        type: DataTypes.STRING 
      },
      refersh_token:{
        type: DataTypes.TEXT
       },

       token: {
        type: DataTypes.TEXT,
      },
      

      device_id: {
        type: DataTypes.STRING,
      },
      device_type: {
        type: DataTypes.ENUM("android", "ios"),
      },
      
      country_code:{
        type:DataTypes.STRING
      },
      verified:{
        type:DataTypes.ENUM(0,1)
      },
      otp:{
        type:DataTypes.STRING
      },
      profile_pic:{
        type:DataTypes.STRING,
      },
      user_role:{
        type:DataTypes.ENUM,
        values:['1','2','3'],
        defaultValue:'2'
      },
      social_type: {
        type: DataTypes.STRING
      },
      social_id:{
        type:DataTypes.TEXT,
        allowNull:true
      },
      location:{
        type:DataTypes.STRING,
        allowNull:true
      },
      status:{
        type:DataTypes.BOOLEAN,
        defaultValue:false
      }
    },
    {
      sequelize,
      modelName: "User",
      tableName: "users",
      timestamps: true,
    }
  );

  return User;
};
