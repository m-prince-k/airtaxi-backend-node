'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class seat_bids extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  seat_bids.init({
    
    user_id: DataTypes.STRING,
    seat_id: DataTypes.STRING,
    bid_price: DataTypes.FLOAT
  }, {
    sequelize,
    modelName: 'seat_bids',
  });
  return seat_bids;
};