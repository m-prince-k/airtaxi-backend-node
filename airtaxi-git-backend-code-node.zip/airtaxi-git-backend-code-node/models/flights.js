'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Flight extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      //Flight.belongsTo(models.Employee,{foreignKey:'user_id'})
      Flight.hasMany(models.FlightSeat,{foreignKey:'flight_id'})
      Flight.hasMany(models.DayOperation,{foreignKey:'flight_id'})
    }
  }
  Flight.init({
    user_id: DataTypes.NUMBER,
    flight_name: DataTypes.STRING,
    flight_desc: DataTypes.STRING,
    from: DataTypes.STRING,
    to: DataTypes.STRING,
    main_price: DataTypes.FLOAT,
    status: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'Flight',
    tableName:'flights',
    timestamps:true
  });
  return Flight;
};