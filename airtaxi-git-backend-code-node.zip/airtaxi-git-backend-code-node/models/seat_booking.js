'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Seat_booking extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Seat_booking.init({
   
    user_id: DataTypes.STRING,
    seat_id: DataTypes.STRING,
    status:{
      type:DataTypes.ENUM,
      values:['1','0'],
      comment:['1 => booked,0 => cancel ']
    },
  }, {
    sequelize,
    modelName: 'Seat_booking',
  });
  return Seat_booking;
};
