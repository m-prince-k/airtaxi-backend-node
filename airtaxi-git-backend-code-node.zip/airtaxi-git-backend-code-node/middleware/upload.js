const fs = require('fs')  
const multer = require('multer')
const path = require("path");
const maxSize = 2 * 1024 * 1024
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // eslint-disable-next-line no-undef
    cb(null, path.join(__dirname+"/../public/upload"),function(err,succ){
        if(err)
        throw err;
    });
  },
  filename: (req, file, cb) => {
    const name = file.originalname.toLowerCase();
    name.replace(/ /g,"-");
    cb(null,name,function(err,succ) {
      if(err)
      throw err;
    });
  }
})
const uploadFile = multer({storage: storage,limits:maxSize});
module.exports = uploadFile