require("dotenv").config;
const jwt = require('jsonwebtoken')
const helper = require('../helper/api-response')
const {User} = require('../models');

const validateAdmin=async(req, res, next) => {
    try {
     const token = req.headers["authorization"]?req.headers["authorization"].split(" ")[1]:'';
      if (!token) {
        return helper.unAuthorizedResponse(res, 'Unauthorized');
      }
      let decode = jwt.verify(token, process.env.JWTSECRETKEY);
      let adminData = await User.findOne({_id:decode.id });
      if (!adminData) {
          return helper.unAuthorizedResponse(res, 'User not found!');
      }
      else{
          req.currentAdmin = adminData;
          next();
      }   
    } catch (err) {
      console.log('__________________________________________',err);
      return helper.unAuthorizedResponse(res, 'Unauthorized')
    }
  }
  module.exports = validateAdmin;validateAdmin