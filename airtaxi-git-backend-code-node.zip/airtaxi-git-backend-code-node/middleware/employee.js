require("dotenv").config;
const jwt = require('jsonwebtoken')
const helper = require('../helper/api-response')
const {Employee} = require('../models');

const validateEmployee=async(req, res, next) => {
    try {
     const token = req.headers["authorization"]?req.headers["authorization"].split(" ")[1]:'';
      if (!token) {
        return helper.unAuthorizedResponse(res, 'Unauthorized');
      }
      let decode = jwt.verify(token, process.env.JWTSECRETKEY);
      let employeeData = await Employee.findOne({_id:decode.id });
      if (!employeeData) {
          return helper.unAuthorizedResponse(res, 'Employee not found!');
      }
      else{
          req.currentEmployee = employeeData;
          next();
      }   
    } catch (err) {
      console.log('__________________________________________',err);
      return helper.unAuthorizedResponse(res, 'Unauthorized')
    }
  }
  module.exports = validateEmployee;