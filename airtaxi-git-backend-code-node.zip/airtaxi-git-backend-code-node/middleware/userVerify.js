require("dotenv").config;
const jwt = require('jsonwebtoken')
const helper = require('../helper/api-response')
const {User} = require('../models');

const validateUser=async(req, res, next) => {

  
    try {
     const token = req.headers["authorization"];
    //  console.log(token)
      if (!token) {
        return helper.unAuthorizedResponse(res, 'Unauthorized');
      }
      let decode = jwt.verify(token, process.env.JWTSECRETKEY);
      console.log(decode,"________________________________________")
      let userData = await User.findOne({_id:decode.id });
      if (!userData) {
          return helper.unAuthorizedResponse(res, 'User not found!');
      }
      else{
          req.currentAdmin = userData;
          next();
      }   
    } catch (err) {
      // console.log('__________________________________________',err);
      return helper.unAuthorizedResponse(res, 'Unauthorized')
    }
  }
  module.exports = validateUser;