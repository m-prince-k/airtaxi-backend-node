require("dotenv").config();
const {Flight, FlightSeat, User, ResetPassword} = require("../models");
const Response = require("./helper/api-response")
const { Validator } = require("node-input-validator");
const { STATUSCODE, VALIDATIONRULE } = require('../helper/messages');
const bcrypt = require("bcrypt");
const sendMailer = require("../helper/sendMailer");
const { default: phone } = require("phone");
const { response } = require("express");

exports.loginByAdmin = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;

    let validationMessage = [email, password];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { email, password } = req.body;
      const emailExist = await User.findOne({ where: { email: email.toLowerCase()} });
      //return res.send(emailExist)
      if(!emailExist){return Response.errorRespose(res,'Email not found')}
      if(emailExist.user_role=='1'){
        if (emailExist?.dataValues?.email) {
          const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
          if (verify) {
            const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
            if (token) {
              emailExist.dataValues.token = token;
              return Response.successResponseWithData(res, "Login Successfully for Admin", emailExist);
            } else {
              return Response.errorRespose(res, "token is not valid");
            }
          } else {
            return Response.errorResposeWithData(res,"password has not been matched");
          }
        } else {
          return Response.errorRespose(res, "Email not exists, Try again");
        }
      } else if(emailExist.user_role=='2'){
        if (emailExist?.dataValues?.email) {
          const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
          if (verify) {
            const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
            if (token) {
              emailExist.dataValues.token = token;
              return Response.successResponseWithData(res, "Login Successfully for by Normal User", emailExist);
            } else {
              return Response.errorRespose(res, "token is not valid");
            }
          } else {
            return Response.errorResposeWithData(res,"password has not been matched");
          }
        } else {
          return Response.errorRespose(res, "Email not exists, Try again");
        }
      } else if (emailExist.user_role=='3') {
        if (emailExist?.dataValues?.email) {
          const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
          if (verify) {
            const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
            if (token) {
              emailExist.dataValues.token = token;
              return Response.successResponseWithData(res, "Login Successfully for by Employee", emailExist);
            } else {
              return Response.errorRespose(res, "token is not valid");
            }
          } else {
            return Response.errorResposeWithData(res,"password has not been matched");
          }
        } else {
          return Response.errorRespose(res, "Email not exists, Try again");
        }
      } else {
        return res.send('detail not found')
      }
      
    }
  } catch (err) {
    return Response.errorRespose(res,err);
  }
}
exports.editProfile = async (req,res) => {
  try {
    const authUser=req.currentAdmin;
    const checkEmailExists=await User.findOne({where:{email:authUser.email}});
    const data=req.body;
    const payload ={
      first_name:data.first_name,
      last_name:data.last_name,
      name:first_name + " " + last_name,
      country_code:data.country_code,
      phone_number:data.phone_number,
      location:data.location,
      email:data.email
    }
    if(req.file){
      payload.profile_pic=req.file.originalname
    }
    const update = await User.update(payload,{where:{id:authUser.id}});
    if(update) {
      return Response.successResponseWithData(res,'Profile has been updated successfully',update)
    } else {
      return Response.errorRespose(res,'something went wrong!');
    }
  } catch (error) {
    console.log('____________________________Error is here',error)
    return Response.errorRespose(res,err);
  }
}
exports.addUser = async (req, res) => {
  try {
const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
        user_role:"required"
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
        "user_role.required":"Please enter the user role"
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;
    let user_role=v.errors.user_role;

    let validationMessage = [email, password, user_role];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { first_name,last_name, email, password, user_role, location,device_token, token, forgot_password_token } = req.body;
      let userPayload={};
      userPayload = {
        first_name:first_name,
        last_name:last_name,
        name: first_name + " " +last_name,
        email: email,
        password: await Response.hashPassword(password, 10),
        user_role: user_role,
        device_token: device_token ? device_token : '',
        token: token,
        location:location,
        forgot_password_token: forgot_password_token ? forgot_password_token : ''
      }
      
      if(req.file) {
        userPayload.profile_pic=req.file.originalname
      }
     
      let checkEmailExistsOrNOT=await Response.checkEntityExistsOrNot(User,{where:{email:email}});
      
      if(!checkEmailExistsOrNOT){
        let createUser = await User.create(userPayload);
        if (createUser) {
          if(user_role==1){
            return Response.successResponseWithData(res, 'User has been Created by Assinged as Admin', createUser)
          } else if(user_role==2){
            return Response.successResponseWithData(res, 'User has been Created by as Normal User', createUser)
          } else if(user_role==3) {
            return Response.successResponseWithData(res, 'User has been Created by as employee', createUser)
          }
        }
      } else  {return Response.errorRespose(res, 'This Employee Email account has been Already Exists')}
    }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
//get All Employee based on user type 3 => employee
exports.getEmployeeListing = async (req,res)=> {
  try {
      let getAllEmployee=await User.findAll({
        where:{user_role:'3'},
        order:[['id','DESC']],
      });
      //return res.send(getAllEmployee)
      if(getAllEmployee.length > 0){
        return Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      } else {
        return Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
//get All User based on user type 2 => employee
exports.getUserListing = async (req,res)=> {
  try {
      let getAllEmployee=await User.findAll({
        where:{user_role:'2'},
        order:[['id','DESC']],
        //distinct:'name'
      });
      //return res.send(getAllEmployee)
      if(getAllEmployee.length > 0){
        return Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      }  else {
        return Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.addFlight = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        flight_name: "required",
        flight_desc: "required",
        main_price: "required"
      },
      {
        "flight_name.required": "Please enter the flight name",
        "flight_desc.required": "Please enter the description",
        "main_price.required": "Please enter main price",
      }
    );
    let check = await v.check();
    let flight_name = v.errors.flight_name;
    let flight_desc = v.errors.flight_desc;
    let main_price = v.errors.main_price;

    let validationMessage = [flight_name, flight_desc, main_price];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { flight_name, flight_desc, from, to, main_price, seatnumber } = req.body;
      let seatBookingDetails=[];
      let createFlight = {
        user_id: parseInt(req.body.user_id),
        flight_name: flight_name,
        flight_desc: flight_desc,
        from: from,
        to: to,
        main_price: main_price
      }
      let _createFlight = await Flight.create(createFlight);
      const getLastFlightId = _createFlight.id;

      //seat booking start here
      if (seatnumber) {
        for (let i=1; i < seatnumber; i++) {
          let data=await FlightSeat.create({flight_id: parseInt(getLastFlightId),desc: req.body.desc,seat_number: "seat no " + parseInt(i)})
        }
      }
      //set flight seats here 
      if (_createFlight) {
        return Response.successResponseWithData(res, 'Flight has been Created Successfully', _createFlight);
      }
    }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.flightListing = async (req, res) => {
  try {
    let getFlights = await Flight.findAll({
      include: [
        {model:FlightSeat, required:false},
        { model: Employee, required: false ,group:['id']}
    ],
      order: [['id', 'DESC']]
    });
    if (getFlights.length > 0) { return Response.successResponseWithData(res, 'FLight Fetched Successfully !', getFlights) }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.editUserByAdmin = async (req, res) => {
  try {
    if(!req.params.id){
       
    } else {
      
      const _id=parseInt(req.params.id)
      const employee = await Response.checkEntityExistsOrNot(User,{where:{id:_id,user_role:2}});
      if(!employee) {return Response.errorRespose(res,'Employee not found')}
      const {first_name, last_name, email, location,password, user_role, device_token, token, phone_number } = req.body;
      let userPayload = {
        name: first_name + " " +last_name,
        email: email,
        password: await Response.hashPassword(password, 10),
        user_role: user_role,
        location:location,
        phone_number: phone_number
      }
      let updateUser = await User.update(userPayload,{where:{id:_id,user_role:'3'}});
      if (updateUser) {
        return Response.successResponseWithData(res, 'User has been Updated Successfully', updateUser)
      }
    }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.activeDisactiveByAdmin=async (req,res)=> {
  try {
      const _id=parseInt(req.params.id);

      const user = await Response.checkEntityExistsOrNot(User,{where:{id:_id,user_role:3}});
      //return res.send(user)
      if(!user) {return Response.errorRespose(res,'Employee not found')}
      if(user.status==0) {
        await User.update({status:1},{where:{id:_id}});
        return Response.successResponse(res,'Employee has been Deactive Successfully')
      } else if(user.status==1) {
        await User.update({status:0},{where:{id:_id}});
        return Response.successResponse(res,'Employee has been Active Successfully')
      }
  } catch (error) {
    return Response.errorRespose(res,error)
  }
},
exports.forgotPasswordBySuperAdmin=async (req,res) => {
  try {
       // return res.send('email sent...,.')
    if(!req.body.email){return Response.errorRespose(res,'Please enter the email address')}
      const checkEntityExists=await Response.checkEntityExistsOrNot(User,{where:{email:req.body.email}})
      let getActiveEmail=await Response.checkEntityExistsOrNot(ResetPassword,{where:{email:req.body.email}})
      if(!checkEntityExists?.dataValues?.email){
        return Response.errorRespose(res,'Email is not exists')
      }
      if(checkEntityExists){
        const token = await Response.generateToken({email:checkEntityExists.email}, process.env.JWTSECRETKEY);
        let url ='<a href='+ process.env.MAIL_BASE_URL+ "/resetPassword/" + token +'">http://' + token +"</a>";
        let expiredTime=Date.now() + 30 * 60 * 1000;

        let _mailSent = await sendMailer("sm954341@gmail.com","kumarprinceseasia@gmail.com","reset password",url)
        if(_mailSent){
          if(!getActiveEmail){
            let existingUpdate=await ResetPassword.create({email:req.body.email,token:token,expired_at:expiredTime})
            return Response.successResponse(res,'Mail has been send to your email id')
          } else {
            let existingUpdate=await ResetPassword.update({email:req.body.email,token:token,expired_at:expiredTime},{where:{email:req.body.email}})
            return Response.successResponse(res,'Mail has been send Successfully !')
          }
        }
      }
  } catch (error) {
    return Response.errorRespose(res,error)
  }
},
exports.resetPasswordBySuperAdmin=async(req,res) => {
  try {
    let v = new Validator(
      req.body,
      {
        new_password: 'required',
        confirm_password:'required|same:new_password'
      },
      {
        'new_password.required': 'Please enter the new password',
        'confirm_password.required': 'Please enter the confirm password',
        'confirm_password.same':'New password and confirm password should be same'
      }
    );
    let check = await v.check();
    let new_password = v.errors.new_password ? v.errors.new_password : "";
    let confirm_password = v.errors.confirm_password ? v.errors.confirm_password : "";
    let validationMessage = [new_password,confirm_password];

    if (!check) {
     return Response.errorRespose(res,validationMessage);
    } else {
     
      const {email,token,expired_at,createdAt}=await Response.checkEntityExistsOrNot(ResetPassword,{where:{email:req.currentAdmin.email}})
      const {new_password,confirm_password}=req.body;
      if(!email){
        return Response.errorRespose(res,'Email is not exists')
      } else if(!token) {return Response.errorRespose(res,'Token not found')}
      
      if(token && email){
          const expiryTime=expired_at - Date.now();
          if(expiryTime < 0 ){
            await ResetPassword.destroy({where:{email:email}});
            return res.send('token has been expired, Try again')
          } else {
            const getOldPassword=await Response.checkEntityExistsOrNot(User,{where:{email:req.currentAdmin.email}})
            let existsOrDbNotMatched=await Response.comparePassword(new_password,getOldPassword.password)
            if(existsOrDbNotMatched) {return Response.errorRespose(res,'You should choose different Password')
            } else {
              const hashedPassword=await Response.hashPassword(new_password,parseInt(process.env.BCRYPT_SALT));
              const updatePassword=await User.update({password:hashedPassword},{where:{email:req.currentAdmin.email}});
              if(updatePassword) {
                await ResetPassword.destroy({where:{email:email}});
                return Response.successResponse(res,'Password has been Reset Successfully !')
              } else {return Response.errorRespose(res,'Something went wrong')}
            }
          }
      }
    }
    
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
// ---------------------------------Employee admin Auth start here------------------------------
exports.employeeLoginAsAdmin = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;

    let validationMessage = [email, password];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { email, password } = req.body;
      const emailExist = await Employee.findOne({ where: { email: email.toLowerCase() } });

      if (emailExist?.dataValues?.email) {
        const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
        if (verify) {
          const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
          if (token) {
            emailExist.dataValues.token = token;
            return Response.successResponseWithData(res, "Employee has been Login Successfully", emailExist);
          } else {
            return Response.errorRespose(res, "token is not valid");
          }
        } else {
          return Response.errorResposeWithData(res,"password has not been matched");
        }
      } else {
        return Response.errorRespose(res, "Email not exists, Try again");
      }
    }
  } catch (err) {
    return Response.errorRespose(res,err);
  }
}




