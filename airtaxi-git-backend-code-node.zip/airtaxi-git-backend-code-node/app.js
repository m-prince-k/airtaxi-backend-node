require('dotenv').config();
const express = require('express');
const app = express();
const httpServer = require("http").createServer(app);
const cors = require('cors');
const helmet=require('helmet');

const compression=require('compression')
const bodyParser = require('body-parser');
const path=require("path")

app.use(compression());
app.use(cors());
app.use(helmet());

app.set("view engine", "ejs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



app.use('/public', express.static('public/upload'))
//app.use("/public", express.static(path.join(__dirname,'../public/upload')));

const adminRoutes = require("./routes/admin_route")
const userRoutes=require("./routes/user_route")

app.use('/api/v1/admin',adminRoutes)
app.use('/api/v1/user',userRoutes)
// app.use('/api')

app.get('/testLanguage',(req,res) => {
   return res.send('sending mail')
});

// app.use(function(req,res){return res.status(400).json({error:'Something went Wrong,Try again'});});


const port = parseInt(process.env.PORT) || 4000;

httpServer.listen(port, (err) => console.log(`Server is listening on port: http://localhost:${port}`));