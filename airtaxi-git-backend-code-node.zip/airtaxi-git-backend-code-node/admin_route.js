const express=require('express');
const router=express.Router();
const AdminController=require("./controller/AdminController");
const AdminVerify=require('../middleware/adminVerify');
const upload=require("../middleware/upload")
// --------------------------------------------- Super admin route start here-------------------------------- 

router.post('/superAdminLogin',AdminController.loginByAdmin);
router.post('/addUser',upload.single('profile_pic'),AdminController.addUser);
router.post('/editProfile',upload.single('profile_pic'),AdminVerify,AdminController.editProfile);
router.post('/abc',AdminVerify,upload.single('profile_pic'),AdminController.addEmployee);

router.post('/editUserByAdmin',AdminVerify,AdminController.editUserByAdmin);
router.post('/addFlight',AdminVerify,AdminController.addFlight)
router.get('/flightListing',AdminVerify,AdminController.flightListing);
router.put('/activeDisactiveByAdmin/:id',AdminVerify,AdminController.activeDisactiveByAdmin);
router.post('/forgotPasswordBySuperAdmin',AdminController.forgotPasswordBySuperAdmin);
router.post('/resetPasswordBySuperAdmin',AdminVerify,AdminController.resetPasswordBySuperAdmin)
router.get('/getEmployeeListing',AdminVerify,AdminController.getEmployeeListing);
router.get('/getUserListing',AdminVerify,AdminController.getUserListing);
router.get("/Count",AdminVerify,AdminController.Count);
// ------------------------------------------------- end of super admin route is here--------------------------


// Admin Employee login start here for super admin
router.post('/employeeLoginAsAdmin',AdminController.employeeLoginAsAdmin)
module.exports=router;