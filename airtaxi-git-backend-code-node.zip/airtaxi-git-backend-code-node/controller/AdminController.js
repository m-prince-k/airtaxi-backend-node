require("dotenv").config();
const {Flight, FlightSeat, User, ResetPassword, Sequelize, DayOperation, Day} = require("../models");
const Response = require("../helper/api-response");
const { Validator } = require("node-input-validator");
const { STATUSCODE, VALIDATIONRULE } = require('../helper/messages');
const bcrypt = require("bcrypt");
const op = Sequelize.Op;
const sendLinkForAdmin =require("../helper/sendLinkForAdmin")
const { STAGING_BASE_URL,LOCAL_BASE_URL } = require("../config/constant");
const path=require("path")
const Op = Sequelize.Op

exports.loginByAdmin = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;

    let validationMessage = [email, password];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { email, password } = req.body;
      const emailExist = await User.findOne({ where: { email: email.toLowerCase()} });
      //return res.send(emailExist)
      if(!emailExist){return Response.errorRespose(res,'Email not found')}
     if(emailExist.user_role=='2'){
      return Response.errorRespose(res,'Invalid username or password')
     }
      if(emailExist?.user_role=='1'){
        if (emailExist?.dataValues?.email) {

          if(emailExist?.dataValues?.status=="1") { 
            return Response.errorRespose(res,'User Blocked By Admin')
          }

          const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
          if (verify) {
            const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
            if (token) {
              emailExist.dataValues.token = token;
              return Response.successResponseWithData(res, "Login Successfully for Admin", emailExist);
            } else {
              return Response.errorRespose(res, "token is not valid");
            }
          } else {
            return Response.errorResposeWithData(res,"password has not been matched");
          }
        } else {
          return Response.errorRespose(res, "Email not exists, Try again");
        }
      } else if (emailExist?.user_role=='3') {
        if (emailExist?.dataValues?.email) {
          
          if(emailExist?.dataValues?.status=="1") { 
            return Response.errorRespose(res,'User Blocked By Admin')
          }
          
          const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
          if (verify) {
            const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
            if (token) {
              emailExist.dataValues.token = token;
              return Response.successResponseWithData(res, "Login Successfully for by Employee", emailExist);
            } else {
              return Response.errorRespose(res, "token is not valid");
            }
          } else {
            return Response.errorResposeWithData(res,"password has not been matched");
          }
        } else {
          return Response.errorRespose(res, "Email not exists, Try again");
        }
      } else {
        return res.send('detail not found')
      }
      
    }
  } catch (err) {
    return Response.errorRespose(res,err);
  }
}
exports.addUser = async (req, res) => {
  try {
const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
        user_role:"required"
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
        "user_role.required":"Please enter the user role"
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;
    let user_role=v.errors.user_role;

    let validationMessage = [email, password, user_role];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { first_name,last_name, email, password, user_role, location,device_token,country_code,phone_number, token, forgot_password_token } = req.body;
      let userPayload={};
      userPayload = {
        first_name:first_name,
        last_name:last_name,
        name: first_name ? first_name : ''  + " " +last_name ? last_name : '',
        email: email,
        password: await Response.hashPassword(password, 10),
        user_role: user_role,
        device_token: device_token ? device_token : '',
        token: token,
        country_code:country_code,
        phone_number:phone_number,
        location:location,
        forgot_password_token: forgot_password_token ? forgot_password_token : ''
      }
      
      if(req.file) {
        userPayload.profile_pic=req.file.originalname
      }
     
      let checkEmailExistsOrNOT=await Response.checkEntityExistsOrNot(User,{where:{email:email}});
      
      if(!checkEmailExistsOrNOT){
        let createUser = await User.create(userPayload);
        if (createUser) {
          if(user_role==1){
            return Response.successResponseWithData(res, 'User has been Created by Assinged as Admin', createUser)
          } else if(user_role==2){
            return Response.successResponseWithData(res, 'User has been Created by as Normal User', createUser)
          }
        }
      } else  {return Response.errorRespose(res, 'This Employee Email account has been Already Exists')}
    }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}

exports.addEmployee = async (req, res) => {
  try {
const v = new Validator(
      req.body,
      {
        email: "required|email",
        user_role:"required"
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "user_role.required":"Please enter the user role"
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;
    let user_role=v.errors.user_role;

    let validationMessage = [email, password, user_role];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { first_name,last_name, email, user_role, location,country_code,phone_number } = req.body;
      let userPayload={};
      let generatePassword=Math.random().toString(36).slice(-8);
      userPayload = {
        first_name:first_name,
        last_name:last_name,
        name: first_name ? first_name : ''  + " " +last_name ? last_name : '',
        email: email,
        password: await Response.hashPassword(generatePassword,10),
        user_role: user_role,
        country_code:country_code,
        phone_number:phone_number,
        location:location,
      }
      //hit mail function for sending the mail 
      let loginLink=`Your Email is ${req.body.email} and Password is <b>${generatePassword}</b> \n Link is Here for Login https://stgphys.appsndevs.com/airtaxi`

      // if(req.file) {
      //   userPayload.profile_pic=req.file.originalname
      // }
      let _mailSent = await sendLinkForAdmin(req.body.email,"kumarprinceseasia@gmail.com","Login Credential",loginLink)

      let checkEmailExistsOrNOT=await Response.checkEntityExistsOrNot(User,{where:{email:email}});
      
      if(!checkEmailExistsOrNOT){
        let createUser = await User.create(userPayload);
        if (createUser) {
          if(user_role==1){
            return Response.successResponseWithData(res, 'User has been Created by Assinged as Admin', createUser)
          } else if(user_role==3){
            return Response.successResponseWithData(res, 'Employee has been Created Successfully', createUser)
          }
        }
      } else  {return Response.errorRespose(res, 'This Employee Email account has been Already Exists')}
    }
  } catch (error) {
    console.log('***********************************************************',error)
    return Response.errorRespose(res,error);
  }
}


//get All Employee based on user type 3 => employee
exports.getEmployeeListing = async (req,res)=> {
  try {
    
      let getAllEmployee=await User.findAll({
        where:{
          user_role:'3',id: {[Op.notIn]:[req.currentAdmin.id]} 
      } ,
        orderBy:[ ['id','DESC'] ]
      });
      if(getAllEmployee.length > 0){
        return await Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      } else {
        return await Response.errorRespose(res,'no record found');
      }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}

exports.Count=async (req,res) => {
  try {
      let getEmployeeCount=await User.count({where:{user_role:3}});
      let userCount=await User.count({where:{user_role:2}});
      let totalseats=await FlightSeat.count();
      let totalFlights=await Flight.count();
      if(getEmployeeCount) {
          return Response.successResponseWithData(res,'total employee is here',{employee:getEmployeeCount,user:userCount,flight:totalFlights,seats:totalseats}) 
      } else {
        return Response.errorRespose(res,'Employee not found')
      }
  } catch (error) {
    console.log('____________________________________Error',)
  }
}
//get All User based on user type 2 => employee
exports.getUserListing = async (req,res)=> {
  try {
      let getAllEmployee=await User.findAll({
        where:{user_role:2,id: {[Op.notIn]:[req.currentAdmin.id]} },
        order:[['id','DESC']],
        //distinct:'name'
      });
      //return res.send(getAllEmployee)
      if(getAllEmployee){
        return Response.successResponseWithData(res,'All the Employee Fetched Successfully',getAllEmployee);
      }  else {
        return Response.errorRespose(res,'User not found');
      }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.viewUser=async (req,res) => {
  try {
    const empId=parseInt(req.params.id);
    let singleEmp=await User.findOne({where:{id:empId,user_role:2}});
    if(singleEmp) {
      return await Response.successResponseWithData(res,'Single user fetched successfully !',singleEmp)
    } else {
      return await Response.errorRespose(res,'User not found')
    }
  } catch (error) {
      return Response.errorRespose(res,error)
  }
}
exports.deleteUser=async (req,res) => {
  if(!parseInt(req.body.id)){
    return Response.errorRespose(res,'User id must be added')
  } else {
    const destroyEmp=await User.destroy({where:{id:parseInt(req.body.id),user_role:2}})
    if(destroyEmp){
      return await Response.successResponseWithData(res,'User has been deleted successfully !',destroyEmp)
    } else {
      return await Response.errorRespose(res,'User not found, Try again')
    }
  }
}
exports.blockUnblockUser=async (req,res)=> {
  try {
    if(!req.body.id){
      return Response.errorRespose(res,'Id must be added')
    } else {
      let user = await User.findOne({where:{id:parseInt(req.body.id)}})
      if(!user) {return await Response.errorRespose(res,'User not found')}
      //return res.json(+user.status==0)
      if(+user.status==0) {

        var update=await User.update({status:'1'},{where:{id:parseInt(req.body.id)}});
        if(update) {
          return await Response.successResponseWithData(res,'User has been Deactive Successfully',user)
        }
      } else if(user?.dataValues?.status==1) {

        await User.update({status:0},{where:{id:parseInt(req.body.id)}});
        return await Response.successResponseWithData(res,'User has been Active Successfully',user)
      }
    }
      
  } catch (error) {
    console.log('______________________________Error is here',error)
    return Response.errorRespose(res,error)
  }
}


exports.editUser = async (req, res) => {
  try {

    let getAllrcord=await User.findAll({where:{email:req.body.email}});
    let check=await Response.checkItemExistsInArrayOrNot(getAllrcord,req.body.email).then(res => {
      console.log('35252535523',res)
    });
    return console.log("_______________________",check)
    

    // if(!req.body.id){
    //    return Response.errorRespose(res,'Please provide the User id')
    // } else {

     
    //   //return res.json({key:path.join(__dirname,"../public/upload/demo.png")})
    //   const user = await User.findOne({where:{id:req.body.id}})
    //   //if(!user) {return Response.errorRespose(res,'User not found')}
    //   if(user) {
    //   const {first_name, last_name, email, location, country_code,phone_number } = req.body;
    //   let userPayload = {
    //     first_name:first_name,
    //     last_name:last_name,
    //     name: first_name + " " +last_name,
    //     email: email,
    //     location:location,
    //     country_code:country_code,
    //     phone_number:phone_number
    //   }
    //   if(req.file) {
    //     userPayload.profile_pic=req.file.originalname
    //   }
    //   let updateUser = await User.update(userPayload,{where:{id:req.body.id}});
    //   if (updateUser) {
    //     return Response.successResponseWithData(res, 'User has been Updated Successfully', updateUser)
    //   }
    // } else {
    //   return Response.errorRespose(res,'User not found')
    // }
    // }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.getFilledUser = async (req,res) => {
  try {
    const getSpecific=await User.findOne({where:{id:parseInt(req.params.id),user_role:2}});
    if(getSpecific) { 
      return Response.successResponseWithData(res,'single fetched User filled succesfully !',getSpecific)
    } else  {
      return Response.errorRespose(res,'No Data Found!')
    }
} catch (error) {
  console.log(error);
  return Response.errorRespose(res,error)
}
}
exports.addFlight = async (req, res) => {
  try {
    for(var i=0;i<=4;i++){
      const random = await Response.makeid(6)
      console.log('random number is here','seat_no_'+random)
    }
    return 
    const getrecord=await Flight.findAll({
      required:false,
      include:[
        {
        model:FlightSeat,
        required:false
      },
      {
        model:DayOperation,required:false,
        include:[{
          model:Day,
          required:false
        }]
      }
    ],
      order:[['id','DESC']]
    });

    return res.send(getrecord)
   
  } catch (error) {
    console.log('______________________-error is here',error)
    return Response.errorRespose(res,error);
  }
}
exports.flightListing = async (req, res) => {
  try {
    let getFlights = await Flight.findAll({
      include: [
        {model:FlightSeat, required:false},
        { model: Employee, required: false ,group:['id']}
    ],
      order: [['id', 'DESC']]
    });
    if (getFlights.length > 0) { return Response.successResponseWithData(res, 'FLight Fetched Successfully !', getFlights) }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}

exports.getAdminProfile=async (req,res) => {
  try {
    const getProfileData=req.currentAdmin;
    if(getProfileData) {
      return Response.successResponseWithData(res,'Profile fetched successfully !',getProfileData)
    } else {
      return Response.errorRespose(res,'Employee not found')
    }
  } catch (error) {
    console.log('_____________________________________________________error',error)
    return Response.error(res,error)
  }
}
exports.viewEmployeeProfile=async (req,res) => {
  try {
    const empId=parseInt(req.params.id);
    let singleEmp=await User.findOne({where:{id:empId,user_role:3}});
    if(singleEmp) {
      return await Response.successResponseWithData(res,'single record fetched successfully !',singleEmp)
    } else {
      return await Response.errorRespose(res,'Employee not found')
    }
  } catch (error) {
      return Response.errorRespose(res,error)
  }
}
exports.deleteEmp=async (req,res) => {
  if(!req.params.id){
    return Response.errorRespose(res,'Employee id must be added')
  } else {
    const destroyEmp=await User.destroy({where:{id:parseInt(req.params.id),user_role:3}})
    if(destroyEmp){
      return await Response.successResponse(res,'Employee has been deleted successfully !')
    } else {
      return await Response.errorRespose(res,'Employee not found, Try again')
    }
  }
}
exports.editEmployeeByAdmin = async (req, res) => {
  try {
    
    if(!req.body.id){
       return Response.errorRespose(res,'Please provide the employee id')
    } else {
      //return res.json({key:path.join(__dirname,"../public/upload/demo.png")})
      const _id=parseInt(req.body.id)
      const employee = await Response.checkEntityExistsOrNot(User,{where:{id:req.body.id}});
     
      if(!employee) {return Response.errorRespose(res,'Employee not found')}
      const {first_name, last_name, email, location,country_code,phone_number } = req.body;
      let userPayload = {
        first_name:first_name,
        last_name:last_name,
        name: first_name + " " +last_name,
        email: email,
        location:location,
        country_code:country_code,
        phone_number:phone_number
      }
      if(req.file) {
        userPayload.profile_pic=req.file.originalname
      }
      let updateUser = await User.update(userPayload,{where:{id:req.body.id}});
      if (updateUser) {
        return Response.successResponseWithData(res, 'Employee has been Updated Successfully', updateUser)
      }
    }
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
exports.getFilledEmployee = async (req,res) => {
  try {
      const getSpecific=await User.findOne({where:{id:parseInt(req.params.id),user_role:'3'}});
      if(getSpecific) { 
        return Response.successResponseWithData(res,'single fetched filled succesfully !',getSpecific)
      } else  {
        return Response.errorRespose(res,'No Data Found!')
      }
  } catch (error) {
    console.log(error);
    return Response.errorRespose(res,error)
  }
}
exports.blockUnblockEmployee=async (req,res)=> {
  try {
      let user = await Response.checkEntityExistsOrNot(User,{where:{id:Number(req.body.id),user_role:3}});
      if(!user) {return Response.errorRespose(res,'Employee not found')}
      if(user?.status==0) {
        await User.update({status:1},{where:{id:req.body.id}});
        return Response.successResponse(res,'Employee has been Deactive Successfully')
      } else if(user?.status==1) {
        await User.update({status:0},{where:{id:req.body.id}});
        return Response.successResponse(res,'Employee has been Active Successfully')
      }
  } catch (error) {
    return Response.errorRespose(res,error)
  }
},
exports.forgotPasswordBySuperAdmin=async (req,res) => {
  try {
    
    if(!req.body.email){return Response.errorRespose(res,'Please enter the email address')}
      const checkEntityExists=await Response.checkEntityExistsOrNot(User,{where:{email:req.body.email}  })
      //check maintain
     if(checkEntityExists?.dataValues?.user_role==2) {return Response.errorRespose(res,'Normal User cannot do forgot password')}
     //check email exists or not 
     if(!checkEntityExists?.dataValues?.email){return Response.errorRespose(res,'Email is not exists')}
      
      if(checkEntityExists){
     
        const token = await Response.generateToken({email:checkEntityExists.email}, process.env.JWTSECRETKEY);
        let url=`${STAGING_BASE_URL}/resetPassword/${token}`;
        
        let expiredTime=Date.now() + 30 * 60 * 1000;
      
       let _mailSent = await sendLinkForAdmin(req.body.email,"kumarprinceseasia@gmail.com","reset password",url)

       let getActiveEmail=await Response.checkEntityExistsOrNot(ResetPassword,{where:{email:req.body.email}})
        //if(_mailSent){
          if(!getActiveEmail){
            let existingUpdate=await ResetPassword.create({email:req.body.email,token:token,expired_at:expiredTime})
            return Response.successResponseWithData(res,'Mail has been send to your email id',url)
          } else {
            let existingUpdate=await ResetPassword.update({email:req.body.email,token:token,expired_at:expiredTime},{where:{email:req.body.email}})
            return Response.successResponseWithData(res,'Mail has been send Successfully !',url)
          }
        //}
      }
  } catch (error) {
    return Response.errorRespose(res,error)
  }
},
exports.resetPasswordBySuperAdmin=async(req,res) => {
  try {
    let v = new Validator(
      req.body,
      {
        new_password: 'required',
        confirm_password:'required|same:new_password'
      },
      {
        'new_password.required': 'Please enter the new password',
        'confirm_password.required': 'Please enter the confirm password',
        'confirm_password.same':'New password and confirm password should be same'
      }
    );
    let check = await v.check();
    let new_password = v.errors.new_password ? v.errors.new_password : "";
    let confirm_password = v.errors.confirm_password ? v.errors.confirm_password : "";
    let validationMessage = [new_password,confirm_password];

    if (!check) {
     return Response.errorRespose(res,validationMessage);
    } else {

      const {new_password,confirm_password}=req.body;
      var resetRecord=await Response.checkEntityExistsOrNot(ResetPassword,{where:{token:req.params.token}})
      
      if(!resetRecord){
        return Response.errorRespose(res,'Token has been expired ,Please try again forgot password')
      } else {
          let expiryTime=resetRecord?.expired_at - new Date().getTime();
          if(expiryTime < 0 ){
          
            return await Response.errorRespose(res,'Token has been expired, Try again')
          } else {
            const getOldPassword=await Response.checkEntityExistsOrNot(User,{where:{email:resetRecord?.email}})
            
            let existsOrDbNotMatched=await Response.comparePassword(new_password,getOldPassword?.password)
            
            if(existsOrDbNotMatched) {return await Response.errorRespose(res,'Old Password and New Password should not be same')
            } else {
              let hashedPassword=await Response.hashPassword(new_password,parseInt(process.env.BCRYPT_SALT));
              var updatePassword=await User.update({password:hashedPassword},{where:{email:getOldPassword?.email}})
              await ResetPassword.destroy({where:{email:resetRecord?.email}});
              return await Response.successResponse(res,'Password has been Reset Successfully !')
            }
          }
        }
   }
    
  } catch (error) {
    return Response.errorRespose(res,error);
  }
}
// ---------------------------------Employee admin Auth start here------------------------------
exports.employeeLoginAsAdmin = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: "required|email",
        password: "required",
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
      }
    );

    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;

    let validationMessage = [email, password];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { email, password } = req.body;
      const emailExist = await Employee.findOne({ where: { email: email.toLowerCase() } });

      if (emailExist?.dataValues?.email) {
        const verify = await bcrypt.compare(password, emailExist.dataValues?.password);
        if (verify) {
          const token = await Response.generateToken({email:emailExist.email,password:emailExist.password}, process.env.JWTSECRETKEY);
          if (token) {
            emailExist.dataValues.token = token;
            return Response.successResponseWithData(res, "Employee has been Login Successfully", emailExist);
          } else {
            return Response.errorRespose(res, "token is not valid");
          }
        } else {
          return Response.errorResposeWithData(res,"password has not been matched");
        }
      } else {
        return Response.errorRespose(res, "Email not exists, Try again");
      }
    }
  } catch (err) {
    return Response.errorRespose(res,err);
  }
}
exports.editProfile = async (req,res) => {
  try {
    const authUser=req.currentAdmin;
    const checkEmailExists=await User.findOne({where:{email:authUser.email}});
    const checkEmailUnique=await User.findAll({where:{email:checkEmailExists.email}});

    const data=req.body;
    const payload ={
      first_name:data.first_name,
      last_name:data.last_name,
      name:first_name + " " + last_name,
      country_code:data.country_code,
      phone_number:data.phone_number,
      location:data.location,
      email:data.email
    }
    if(req.file){
      payload.profile_pic=req.file.originalname
    }
    if(!checkEmailUnique){
      const update = await User.update(payload,{where:{id:authUser.id}});
      if(update) {
        return Response.successResponseWithData(res,'Profile has been updated successfully',update)
      } else {
        return Response.errorRespose(res,'something went wrong!');
      }
    } else {
      return Response.errorRespose(res,'This Email is already taken choose different');
    }

  } catch (error) {
    console.log('____________________________Error is here',error)
    return Response.errorRespose(res,err);
  }
}




