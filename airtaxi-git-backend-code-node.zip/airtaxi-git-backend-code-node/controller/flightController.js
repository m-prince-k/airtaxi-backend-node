exports.addTravelling=async(req,res)=>{
    try{
        const payload=req.body
        

    }
    catch(err)
    {

    }
}