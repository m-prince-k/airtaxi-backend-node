require("dotenv").config();
const { User, sequelize } = require("../models");
const path = require("path")

const Response = require("../helper/api-response");
const validatePhoneNumber = require('validate-phone-number-node-js');
const { Validator } = require("node-input-validator");
const { STATUSCODE, VALIDATIONRULE } = require("../helper/messages");
const bcrypt = require("bcrypt");
const { response } = require("express");
const jwt_decode = require("jwt-decode");
const saltRounds = 10;
const generateOtp = require("../helper/sendOtp")
const { where, or } = require("sequelize");
const sequelize2 = require("sequelize");
const Op = sequelize2.Op
const sendMailer = require("../helper/sendMailer");
const { EmailAddress } = require("@sendgrid/helpers/classes");
const { default: phone } = require("phone");
const { contentSecurityPolicy } = require("helmet");
const { default: jwtDecode } = require("jwt-decode");
const whatsapp = require("../helper/whatsappOtp")


const { CallPage } = require("twilio/lib/rest/insights/v1/call");
const { UserRolesContext } = require("twilio/lib/rest/flexApi/v1/userRoles");
// ***************************************** REGISTER BY USER *************************************
exports.registerByUser = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: VALIDATIONRULE.REQUIRED + "|" + VALIDATIONRULE.EMAIL,
        password: VALIDATIONRULE.REQUIRED,
        phone_number: VALIDATIONRULE.REQUIRED
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
        "phone_number.required": "Please enter the Phone Number",
      }
    );
    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;
    let phone_number = v.errors.phone_number
    let validationMessage = [email, password, phone_number];
    if (!check) {
      return Response.validationError(res, validationMessage);
    }
    const emailExist = await User.findOne({
      where: { email: req.body.email.toLowerCase() },
    });
    const checkNumber = await User.findOne({
      where: { phone_number: req.body.phone_number },
    });
    if (!emailExist && !checkNumber) {
      const encryptedPass = await bcrypt.hash(req.body.password, saltRounds);
      const data = {
        ...req.body,
        password: encryptedPass,
      };
      const added = await User.create(data);
      if (added) {
        let response = {
          success: true,
          statusCode: 200,
          data: data,
          message: "user register succesfully",
        }
        res.json(response);
      }
    }
    else {
      res.status(401).send({ message: "email or phone number already exist" });
    }
  }
  catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(400).json(response);

  }
};
// ****************************************** SEND OTP BY USER ******************************************
exports.sendOtpByUSer = async (req, res) => {
  try {
    const email = req.body.email;
    const phone_number = req.body.phone_number;
    const whatsapp_number = req.body.whatsapp_number;
    let otpNumber = Math.floor(1000 + Math.random() * 9000);
    if (email) {
      const emailExist = await User.findOne({ where: { email: email.toLowerCase() } });
      if (emailExist) {
        const added = await User.update({ otp: otpNumber }, { where: { id: emailExist.id } })
        const sendmail = await sendMailer(email, otpNumber);
        let response = {
          success: true,
          statusCode: 200,
          message: "Otp  has been send to your Email",
        }
        res.json(response);
      } else {
        return res.status(401).send({ message: "Email is not valid" })
      }
    }
    if (phone_number) {
      const phoneExist = await User.findOne({
        where: { phone_number: phone_number }
      });
      if (phoneExist) {
        var data = await generateOtp.generateOtp(phone_number, otpNumber)
        const added = await User.update({ otp: otpNumber }, { where: { id: phoneExist.id } })
        if (added) {
          let response = {
            success: true,
            statusCode: 200,
            message: "Otp  has been send to your PhoneNumber"
          }
          res.json(response);
        } else {
          return res.status(401).send({ message: "Failed to send Otp" })
        }

      }
    }
    if (whatsapp_number) {
      const phoneExist = await User.findOne({
        where: { phone_number: whatsapp_number }
      });
      if (phoneExist) {
        var data = await whatsapp.sendWhatsappCode(phone_number, otpNumber)
        const added = await User.update({ otp: otpNumber }, { where: { id: phoneExist.id } })
        if (added) {
          let response = {
            success: true,
            statusCode: 200,
            message: "Otp  has been send to your Whatsapp Number"
          }
          res.json(response);
        } else {
          return res.status(401).send({ message: "Failed to send Otp" })
        }

      }

    }
    else {
      return res.status(401).send({ message: "Email or Number does not exist" })
    }
  } catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response);


  }
}
// ****************************************** VERIFY OTP BY USER ******************************************
exports.verifyOtpByUser = async (req, res) => {
  try {
    const data = req.body.otp
    const email = req.body.email
    const phone_number = req.body.phone_number;
    if (data && email) {
      let emailExist = await User.findOne({
        where: {
          [Op.and]: [{ email: email.toLowerCase() }, { otp: data }]
        }
      })
      if (emailExist) {
        let payload = {
          name: emailExist.dataValues.name,
          email: emailExist.dataValues.email,
          id: emailExist.dataValues.id,
          phone_number: emailExist.dataValues.phone_number
        }
        let token = await Response.generateToken(payload, process.env.JWTSECRETKEY);
        let refersh_token = await Response.generateRefreshToken(payload, process.env.JWTSECRETKEY);
        let result = await User.update({ status: 1, token: token, refersh_token: refersh_token }, { where: { id: emailExist.id } });
        let responseData = { ...emailExist.dataValues, token, refersh_token }
        return res.status(200).send({ message: "Otp Verified Successfully", data: responseData })
      }
      else {
        return res.status(401).send({ message: "Otp did'nt matched" })
      }
    }
    if (data && phone_number) {
      const phoneExist = await User.findOne({
        where: {
          [Op.and]: [{ phone_number: phone_number }, { otp: data }]
        }
      })
      if (phoneExist) {
        let payload = {
          name: phoneExist.dataValues.name,
          email: phoneExist.dataValues.email,
          id: phoneExist.dataValues.id,
          phone_number: phoneExist.dataValues.phone_number
        }
        let token = await Response.generateToken(payload, process.env.JWTSECRETKEY);
        let refersh_token = await Response.generateRefreshToken(payload, process.env.JWTSECRETKEY);
        let result = await User.update({ status: 1, token: token, refersh_token: refersh_token }, { where: { id: phoneExist.id } });
        let responseData = { ...phoneExist.dataValues, token, refersh_token }

        return res.status(200).send({ message: "Otp verified successfully", data: responseData })
      }
      else {
        return res.status(401).send({ message: "Otp did'nt matched" })
      }
    }
  }

  catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response);

  }
}
// ******************************************* LOGIN BY USER **********************************************
exports.loginByUSer = async (req, res) => {
  try {
    const v = new Validator(
      req.body,
      {
        email: VALIDATIONRULE.REQUIRED + "|" + VALIDATIONRULE.EMAIL,
        password: VALIDATIONRULE.REQUIRED,
      },
      {
        "email.required": "Please enter the email address",
        "email.email": "Please enter the valid email address",
        "password.required": "Please enter the password",
      }
    );
    let check = await v.check();
    let email = v.errors.email;
    let password = v.errors.password;
    let validationMessage = [email, password];
    if (!check) {
      return Response.validationError(res, validationMessage);
    } else {
      const { email, password } = req.body;
      const emailExist = await User.findOne({
        where: { email: email.toLowerCase() },
      });

      if (!emailExist) {
        return res.status(401).json({
          message: "Email does not exist",
        });
      } else {
        const verify = await bcrypt.compare(
          password,
          emailExist.dataValues?.password
        );

        if (!verify) {
          return res.status(401).json({
            message: "Password not matched",
          });
        } else {
          if (emailExist?.dataValues?.status == 1) {
            let jwtPayload = {
              name: emailExist.dataValues.name,
              email: emailExist.dataValues.email,
              id: emailExist.dataValues.id,
              phone_number: emailExist.dataValues.phone_number
            }

            let token = await Response.generateToken(jwtPayload, process.env.JWTSECRETKEY);
            let refersh_token = await Response.generateRefreshToken({ jwtPayload });
            let result = await User.update({ token: token, refersh_token: refersh_token }, { where: { id: emailExist.id } });
            let responseData = {
              ...emailExist.dataValues,
              token,
              refersh_token
            }

            console.log(responseData)
            return res.status(200).json({
              message: "Login Successfully",
              data: responseData
            });

          }
        }
      }
    }
  } catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response);

  }
};
// ****************************************** FORGOT PASSWORD BY USER ********************************
exports.forgotPasswordByUser = async (req, res) => {

  const { emailorPhone } = req.body
  let otpNumber = Math.floor(1000 + Math.random() * 9000);

  try {
    const checktoExist = await User.findOne({
      where: {
        [Op.or]: [{ email: emailorPhone }, { phone_number: emailorPhone }]
      },
    });
    if (checktoExist) {
      if (checktoExist.dataValues.status == 1) {
        var emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
        if (emailorPhone !== '' && emailorPhone.match(emailFormat)) {
          const sendmail = await sendMailer(emailorPhone, otpNumber);
          return res.status(200).send({ message: "Otp Send" })
        } else {
          var sendOtp = await generateOtp.generateOtp(emailorPhone, otpNumber)
          return res.status(200).send({ message: "Otp Send" })
        }
      }
      else {
        return res.status(408).send({ message: "User not verified" })
      }
    }
    else {
      return res.status(200).send({ message: "Email Or number is not Valid" })
    }
  }
  catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response);

  }
};
// ****************************************** RESET PASSWORD BY USER***************************************
exports.resetPasswordByUser = async (req, res) => {
  try {
    const { new_password, confirm_password, email } = req.body
    const userData = await User.findOne({ where: { email: email.toLowerCase() } })
    if (userData) {
      let hashpassword;
      if (new_password === confirm_password) {
        const salt = await bcrypt.genSalt(10)
        hashpassword = await bcrypt.hash(new_password, salt)

        if (hashpassword.length > 0) {
          const added = await User.update({ password: hashpassword }, { where: { email: userData.email } })
          if (added) {
            const response = {
              success: true,
              statusCode: 200,
              message: 'Password changed successfully.'
            }
            return res.json(response)
          }
        }
      } else {
        return res.status(401).json({
          success: true,
          message: 'Confirm password or new password is not matched.'
        })
      }
    } else {
      return res.status(408).json({
        success: true,
        statusCode: 500,
        message: 'Email not Exist'
      })

    }
  } catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response);

  }
};
// *********************************************** SOCIAL REGISTER BY USER ***************************************************
exports.socialRegister = async (req, res) => {
  const { social_type, social_id, name, phone_number, email } = req.body;
  // return res.send(path.join(__dirname,'../public/upload/demo.png'))
  try {

    const token = await Response.generateToken({ socialType: req.body }, process.env.JWTSECRETKEY)

    const getRecordBySociallLite = await User.findOne({ where: { social_id: social_id } });
    let refersh_token = await Response.generateRefreshToken({ getRecordBySociallLite, key: process.env.JWTSECRETKEY });

    // let token = await Response.generateToken(getRecordBySociallLite, process.env.JWTSECRETKEY);
    if (!getRecordBySociallLite) {
      let payload = {
        ...req.body, token, refersh_token

      }

      const createdNew = await User.create(payload);
      if (createdNew) {
        return Response.successResponseWithData(res, "social lite registered successfully", createdNew)
      }
    } else {
      let payload = {
        ...req.body, token, refersh_token


      }
      const updateUser = await User.update({ payload }, { where: { social_id: social_id } });
      let userData = await User.findOne({
        where: { social_id: social_id },
      });

      return Response.successResponseWithData(res, "Successfully Login by social media", userData);
    }
  }

  catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err?.message
    }
    res.status(500).json(response);
  }
}
// ************************************ CHANGES PASSWORD BY USER ***********************************
exports.changePaswordByUser = async (req, res) => {
  try {
    let v = new Validator(
      req.body,
      {
        new_password: 'required',
        confirm_password: 'required|same:new_password',
        old_password: 'required'
      },
      {
        'new_password.required': 'Please enter the new password',
        'confirm_password.required': 'Please enter the confirm password',
        'confirm_password.same': 'New password and confirm password should be same',
        'old_password': "Please enter the old password"
      }
    );
    let check = await v.check();
    let new_password = v.errors.new_password;
    let old_password = v.errors.old_password
    let confirm_password = v.errors.confirm_password;
    let validationMessage = [new_password, confirm_password, old_password];
    if (!check) {
      return Response.errorRespose(res, validationMessage);
    }
    else {

      const { new_password, confirm_password, old_password } = req.body
      if (old_password != new_password) {
        const salt = await bcrypt.genSalt(12)
        hashpassword = await bcrypt.hash(new_password, salt)
        const resetRecord = await User.findOne({ where: { token: req.headers.authorization } })
        if (!resetRecord) {
          return res.status(404).send({ message: 'Token not found ,Try again' })
        } else {
          const isValidPassword = await bcrypt.compare(old_password, resetRecord?.dataValues?.password, async (err, decoded) => {
            if (decoded) {
              User.update({ password: hashpassword }, { where: { id: resetRecord.dataValues.id } }).then(
                res.status(200).send({ message: 'password update Succcesful' })
              ).catch((err) => {
                res.send(err)
              });
            }
            else {
              res.status(400).send({ message: "old password not matched" })
            }
          });
        }
      } else {
        res.status(400).send({ message: "old password and new password cannot be same" })
      }

    }
  }


  catch (err) {
    console.log(err)
    // let response = {
    //   Error: err.message
    // }
    // res.status(500).send(response);

  }
}
// ********************************** GET USER BY EMAIL OR PHONE **********************************************
exports.getUserByEmailorPhone = async (req, res) => {
  try {
    const { emailorPhone } = req.body
    const checktoExist = await User.findOne({
      where: {
        [Op.or]: [{ email: emailorPhone }, { phone_number: emailorPhone }]
      },
    });
    if (checktoExist) {
      res.status(200).send(checktoExist)
    }
    else {
      res.status(401).send({ message: "phone number doesn't exist or user not verified" })
    }
  } catch (err) {
    let response = {
      success: false,
      statusCode: 500,
      Error: err.message
    }
    res.status(500).json(response)
  }
}
exports.autoLogin = async (req, res) => {
  try {
    console.log(req.headers.authorization, "L")
    const data = await User.findOne({ where: { refersh_token: req.headers.authorization } })
    if (!data) {
      res.send("Token is Expired")
    } else {
      res.send(data)
    }



  }
  catch (err) {
    console.log(err)
  }
}
