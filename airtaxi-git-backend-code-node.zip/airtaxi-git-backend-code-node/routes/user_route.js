const express=require('express');
const router=express.Router();
const userController=require("../controller/UserController");
const UserVerify=require("../middleware/userVerify")
const upload=require("../middleware/upload")

// **************************USER ROUTE************************* 

router.post('/login',userController.loginByUSer);
router.post('/register',userController.registerByUser)
router.post('/forgotPassword',userController.forgotPasswordByUser)
router.post('/resetpassword',userController.resetPasswordByUser)
router.post("/socialRegister",userController.socialRegister)
router.post("/sendOtp",userController.sendOtpByUSer)
router.post('/verifyOtp',userController.verifyOtpByUser)
router.post('/changePassword',UserVerify,userController.changePaswordByUser)
router.post('/getuserbyemailorphone',userController.getUserByEmailorPhone )
router.post('/autoLogin',UserVerify,userController.autoLogin)








module.exports=router;