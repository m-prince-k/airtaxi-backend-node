const express=require('express');
const router=express.Router();
const AdminController=require("../controller/AdminController");
const AdminVerify=require('../middleware/adminVerify');
const upload=require("../middleware/upload")
// --------------------------------------------- Super admin route start here-------------------------------- 

router.post('/superAdminLogin',AdminController.loginByAdmin);
router.post('/editProfile',AdminVerify,AdminController.editProfile);
router.post("/addemployee",AdminVerify,upload.single('profile_pic'),AdminController.addEmployee)




router.get('/getFilledEmployee/:id?',AdminVerify,AdminController.getFilledEmployee);
router.get('/addFlight',AdminController.addFlight)
router.get('/flightListing',AdminVerify,AdminController.flightListing);
router.get("/getUserProfile",AdminVerify,AdminController.getAdminProfile)

router.post('/addUser',upload.single('profile_pic'),AdminController.addUser);
 router.post('/editEmployeeByAdmin',upload.single('profile_pic'),AdminVerify,AdminController.editEmployeeByAdmin);
router.get("/viewEmployeeProfile/:id",AdminVerify,AdminController.viewEmployeeProfile)
router.delete("/deleteEmp/:id",AdminVerify,AdminController.deleteEmp)
router.get('/getEmployeeListing',AdminVerify,AdminController.getEmployeeListing);
router.get('/Count',AdminVerify,AdminController.Count);

 router.post('/blockUnblockEmployee',AdminVerify,AdminController.blockUnblockEmployee); //defective api would be repair
 



 router.post('/forgotPasswordBySuperAdmin',AdminController.forgotPasswordBySuperAdmin);
 router.post('/resetPasswordBySuperAdmin/:token?',AdminController.resetPasswordBySuperAdmin)

//  -------------------------------------------User management api here-----------------------------------------
router.get('/getUserListing',AdminVerify,AdminController.getUserListing);
router.get('/viewUser/:id',AdminVerify,AdminController.viewUser);
router.post('/deleteUser',AdminVerify,AdminController.deleteUser);
router.post('/blockUnblockUser',AdminVerify,AdminController.blockUnblockUser);
router.post('/editUser',AdminController.editUser)
router.get('/getFilledUser/:id',AdminVerify,AdminController.getFilledUser);
// ------------------------------------------------- end of super admin route is here--------------------------


// Admin Employee login start here for super admin
router.post('/employeeLoginAsAdmin',AdminController.employeeLoginAsAdmin)
module.exports=router;