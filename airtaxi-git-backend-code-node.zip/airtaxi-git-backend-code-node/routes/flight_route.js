const express=require('express');
const router=express.Router();
const flightController=require("../controller/flightController");

// ****************************** FLIGHT BOOK *****************************

router.post('/oneway',flightController.addTravelling);
